<?php
include('css_admin.php');
session_start();
?>

<body id="page-top">


          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              
            </div>
            <div class="card-body">

            <h3 class="m-0 font-weight-bold text-secondary" align="center">PEMERINTAH KOTA CIMAHI</h3>
            <h4 class="m-0 font-weight-bold text-secondary" align="center">KELURAHAN PASIRKALIKI KECAMATAN CIMAHI UTARA</h4>
            <h6 class="m-0 font-weight-bold text-secondary" align="center">KP RANCABALI  RT 06 RW 03 Kode Pos 40514</h6>
            <br>
            <br>
            <hr>
            <h4 class="m-0 font-weight-bold text-secondary" align="center">LAPORAN TANGGAPAN</h4>
            <br>
            <br>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  
                   <tr> 
                   <th>Id Tanggapan</th>
                        <th>Id Pegaduan</th>
                        <th>Tgl Tanggapan</th>
                        <th>Tanggapan</th>
                        <th>Id Petugas</th>
                   </tr>
                 
                

                  <?php
                  require '../koneksi.php';
                  $sql=mysqli_query($koneksi, "SELECT * FROM tanggapan");
                  while ($data=mysqli_fetch_array($sql)){

                  ?>
                  
                  <tbody>
                    <tr>
                     
                    <td><?php echo $data['id_tanggapan']; ?></td>
                      <td><?php echo $data['id_pengaduan']; ?></td>
                      <td><?php echo $data['tgl_tanggapan']; ?></td>
                      <td><?php echo $data['tanggapan']; ?></td>
                      <td><?php echo $data['id_petugas']; ?></td>
                    </tr>
       
                  </tbody>

                  
                  <?php }?>
                  </table>    
                  
          </div>
                <br>
                  <br>        
                  <h6 class="m-0 font-weight-bold text-primary" align="right">Cimahi, <?php echo date('d m Y'); ?></h6>       
                  <h6 class="m-0 font-weight-bold text-primary" align="right">Petugas,</h6>
                    <br><br><br><br>
                  <h6 class="m-0 font-weight-bold ht-text-primary" align="right"><?php echo $_SESSION['nama']; ?></h6>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
           
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    <!-- End of Content Wrapper -->

  
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


</body>

</html>
