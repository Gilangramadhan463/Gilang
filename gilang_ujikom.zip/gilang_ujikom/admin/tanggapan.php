

<body id="page-top">

<div class="card shadow">
    <div class="card-header">
        Tanggapan
    </div>

    <?php
            require '../koneksi.php';
            $sql=mysqli_query($koneksi,"SELECT * FROM pengaduan WHERE id_pengaduan='$_GET[id]'");
            $data=mysqli_fetch_array($sql);
            if ($sql)
            {
                ?>

<div class="card-body">
<div class="form-group cols-sm-6">
    <a href="?url=verifikasi_pengaduan" class="btn btn-primary  btn-icon-split">
        <span class="icon text-white-50">
            <i class="fas fa-arrow-left"></i>
        </span>
        <span class="text">Kembali</span>
    </a>
   
    

<form action="simpan_tanggapan.php" method="post" class="form-horizontal" enctype="multipart/form-data">
    

<div class="card-shadow">
            <div class="form-group cols-sm-6">
                <label>Id Pengaduan</label>
                <input type="text" name="id_pengaduan" value="<?php echo $_GET['id']; ?>" class="form-control" readonly>
            </div

            <div class="card-shadow">
            <div class="form-group cols-sm-6">
                <label>Tanggal Tanggapan</label>
                <input type="text" name="tgl_tanggapan" value="<?php echo date('Y-m-d'); ?>" class="form-control" readonly>
            </div>

         
            <div class="form-group cols-sm-6">
                <label>Tulis Tanggapan</label>
                <textarea class="form-control" rows="7" name="tanggapan" required>
                
                </textarea>
            </div>
            <div class="form-group cols-sm-6">
                <label>ID Petugas</label>
             
               <input type="text" name="id_petugas" value="<?php echo $_SESSION['id_petugas']; ?>" class="form-control" readonly>
  
            </div>
            <center>
            <input type="submit" class="btn btn-success btn-user" value="Tanggapi">
            </center>
           
        </form>
        <?php } ?>
        </div>
</div>  


</body>

</html>
