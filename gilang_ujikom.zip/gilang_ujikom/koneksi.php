<?php
$koneksi = mysqli_connect("localhost", "root", "", "ukom");


?>